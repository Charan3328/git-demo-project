﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Digital_Retailers.Models
{
    public class Line
    {
        [Key]
        public int LineId { get; set; }
        [ForeignKey("OrderId")]
        public virtual int OrderId { get; set; }
        //public Product Product { get; set; }
        [ForeignKey("ProductId")]
        public virtual int ProductId { get; set; }
        public int Quantity { get; set; }

        public virtual Order Order { get; set; }
        public virtual Product Product { get; set; }




    }
}
