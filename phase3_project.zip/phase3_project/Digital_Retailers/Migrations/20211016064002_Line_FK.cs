﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Digital_Retailers.Migrations
{
    public partial class Line_FK : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateIndex(
                name: "IX_Lines_OrderId",
                table: "Lines",
                column: "OrderId");

            migrationBuilder.CreateIndex(
                name: "IX_Lines_ProductId",
                table: "Lines",
                column: "ProductId");

            migrationBuilder.AddForeignKey(
                name: "FK_Lines_Orders_OrderId",
                table: "Lines",
                column: "OrderId",
                principalTable: "Orders",
                principalColumn: "OrderId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Lines_Products_ProductId",
                table: "Lines",
                column: "ProductId",
                principalTable: "Products",
                principalColumn: "ProductId",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Lines_Orders_OrderId",
                table: "Lines");

            migrationBuilder.DropForeignKey(
                name: "FK_Lines_Products_ProductId",
                table: "Lines");

            migrationBuilder.DropIndex(
                name: "IX_Lines_OrderId",
                table: "Lines");

            migrationBuilder.DropIndex(
                name: "IX_Lines_ProductId",
                table: "Lines");
        }
    }
}
