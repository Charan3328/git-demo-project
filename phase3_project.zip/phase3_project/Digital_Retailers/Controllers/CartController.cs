﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Digital_Retailers.Helpers;
using Digital_Retailers.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace coreSessionManagementApplication.Controllers
{
    public class CartController : Controller
    {
        ApplicationDBContext context;
        public CartController()
        {
            context = new ApplicationDBContext();
        }
        public IActionResult Index()
        {

            if(SessionHelper.GetObjectFromJson<List<Line>>(HttpContext.Session, "cart") == null)
            {
                return View("CartEmpty");
            }
            else
            {
                var cart = SessionHelper.GetObjectFromJson<List<Line>>(HttpContext.Session, "cart");
                ViewBag.cart = cart;
                ViewBag.total = cart.Sum(Line => Line.Product.Price * Line.Quantity);
                return View();
            }
            
        }

        public IActionResult Buy(int id)
        {
            if(SessionHelper.GetObjectFromJson<List<Line>>(HttpContext.Session, "cart") == null)
            {
                List<Line> cart = new List<Line>();
                cart.Add(new Line{ Product = context.Products.Find(id) , Quantity = 1 });
                SessionHelper.setObjectAsJson(HttpContext.Session, "cart", cart);
            }
            else
            {
                List<Line> cart = SessionHelper.GetObjectFromJson<List<Line>>(HttpContext.Session, "cart");
                int index = isExists(id);
                if(index != -1)
                {
                    cart[index].Quantity++;
                }
                else
                {
                    cart.Add(new Line { Product = context.Products.Find(id), Quantity = 1 });
                }
                SessionHelper.setObjectAsJson(HttpContext.Session, "cart", cart);
            }
            return RedirectToAction("Index");
        }

        public int isExists(int id)
        {
            List<Line> cart = SessionHelper.GetObjectFromJson<List<Line>>(HttpContext.Session, "cart");
            for (int i = 0; i < cart.Count; i++)
            {
                if(cart[i].Product.ProductId == id)
                {
                    return i;
                }
            }
            return -1;
        }

        public IActionResult Checkout()
        {
            if (SessionHelper.GetObjectFromJson<User>(HttpContext.Session, "user") != null)
            {
                SessionHelper.setObjectAsJson(HttpContext.Session, "cart", null);
                return View();
            }
            else
            {
                return RedirectToAction("Index", "Account");
            }
                
        }

      
    }
}
